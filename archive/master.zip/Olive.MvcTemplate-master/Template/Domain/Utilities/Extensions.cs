﻿namespace Domain
{
    using System;
    using System.Linq;
    using System.Collections;
    using System.Collections.Generic;

    /// <summary>
    /// Provides the business logic for Extensions class.
    /// </summary>
    public static class Extensions
    {
    }
}