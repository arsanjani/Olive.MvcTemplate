JavaScript libraries that aren't on Bower can be added in this folder.
Make sure they are referenced in the /ScriptReferences.json.